module.exports=[59904,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_movies_top-rated_route_actions_10vjqhw.js.map