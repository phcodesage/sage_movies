module.exports=[92555,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_movies_latest_route_actions_13pg6xh.js.map