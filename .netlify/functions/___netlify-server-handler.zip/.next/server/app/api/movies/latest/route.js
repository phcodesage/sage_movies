var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/movies/latest/route.js")
R.c("server/chunks/[root-of-the-server]__112tj2m._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_movies_latest_route_actions_13pg6xh.js")
R.m(31112)
module.exports=R.m(31112).exports
