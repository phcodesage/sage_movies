var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/movies/top-rated/route.js")
R.c("server/chunks/[root-of-the-server]__0dvl-tx._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_movies_top-rated_route_actions_10vjqhw.js")
R.m(79617)
module.exports=R.m(79617).exports
