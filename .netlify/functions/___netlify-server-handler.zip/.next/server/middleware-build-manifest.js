globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/E3DERr0tBbfnlNasBPfwq/_buildManifest.js",
    "static/E3DERr0tBbfnlNasBPfwq/_ssgManifest.js",
    "static/E3DERr0tBbfnlNasBPfwq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/154yue4_t6fan.js",
    "static/chunks/0cje14_narrpx.js",
    "static/chunks/0wyz3fzjhpvhl.js",
    "static/chunks/0yoi6g0rt32bk.js",
    "static/chunks/turbopack-02f9oyzxxcy8q.js"
  ]
};
