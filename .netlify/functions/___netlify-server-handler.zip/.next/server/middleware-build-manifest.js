globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/aukezcpiJWQmRwKAnhOgZ/_buildManifest.js",
    "static/aukezcpiJWQmRwKAnhOgZ/_ssgManifest.js",
    "static/aukezcpiJWQmRwKAnhOgZ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/02q.67qgce301.js",
    "static/chunks/0cje14_narrpx.js",
    "static/chunks/0wyz3fzjhpvhl.js",
    "static/chunks/0yoi6g0rt32bk.js",
    "static/chunks/turbopack-10rjyrlcx1~5o.js"
  ]
};
